//========start owl-carousel========

$(document).ready(function(){
    $(".header-content").owlCarousel({
        items: 1,
        loop: true,
        nav: true,
        autoplay:true,
        dots: false,
        navText: ['<i class="icofont icofont-long-arrow-left"></i>', '<i class="icofont icofont-long-arrow-right"></i>'],
    });
});


    $(".customer-content").owlCarousel({
        items: 2,
        loop: true,
        margin:25,
        autoplay:true,
        dots: true, 
    });
//========end owl-carousel========


//========start progress bar========

$(document).ready(function(){
    
    
 var opt = {
 foreColor:'#f2784b',
 
};
$('#progress-s').barIndicator(opt); 
    

$('#progress-2').barIndicator(opt); 
    


$('#progress-3').barIndicator(opt); 
    console.log(".barIndicator")


$('#progress-4').barIndicator(opt); 
    
});
//========end progress bar========

$(window).load(function(){
    $(".preloader").fadeOut(3000);
});



