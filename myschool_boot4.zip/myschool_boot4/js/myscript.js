$(document).ready(function(){
	var menuPosition=$("#navpos").offset().top;
   $(window).scroll(function(){
	   var currentScrollPosition=$(this).scrollTop();
	   if(currentScrollPosition>=menuPosition)
	   {
		 $(".myheader").addClass('menu-position');  
	   
	   }
	   
	   else
	   {
		 $(".myheader").removeClass('menu-position');  
	      
	   }
	   
   });
});